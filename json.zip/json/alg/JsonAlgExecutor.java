package com.wu.rcs.rules.utils.json.alg;

import java.util.Objects;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

/**
 * @author:MG01867
 * @date:2018年4月20日
 * @E-mail:359852326@qq.com
 * @version:
 * @describe json算法执行器
 */
public class JsonAlgExecutor {

	private JsonElement element;

	public JsonAlgExecutor(JsonElement element) {
		Objects.requireNonNull(element);
		this.element = element;
	}

	public JsonAlgExecutor(String json) {
		this(new JsonParser().parse(json));
	}

	public Object getValue(JsonAlgFunction<?> aggElFunction) {
		return aggElFunction.getResult(element);
	}

}
