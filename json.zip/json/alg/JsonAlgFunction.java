package com.wu.rcs.rules.utils.json.alg;

import com.google.gson.JsonElement;

/**
 * @author:MG01867
 * @date:2018年4月20日
 * @E-mail:359852326@qq.com
 * @version:
 * @describe json算法方法顶级接口
 */
public interface JsonAlgFunction<T> {

	T getResult(JsonElement element);
}
