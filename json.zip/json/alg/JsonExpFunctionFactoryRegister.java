package com.wu.rcs.rules.utils.json.alg;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;


/**
 * @author:MG01867
 * @date:2018年4月20日
 * @E-mail:359852326@qq.com
 * @version:
 * @describe json算法工厂注册器
 */
public class JsonExpFunctionFactoryRegister {

	private static Map<Class<?>, JsonAlgFunctionFactory<?>> jsonAlgFunctionFactoryMap = new HashMap<>();

	static {
		register(new IfElFunctionFactory());
		register(new OrElFunctionFactory());
		register(new AndElFunctionFactory());
		register(new EqualsElFunctionFactory());
		register(new LessThanElFunctionFactory());
		register(new LessThanAndEqualsElFunctionFactory());
		register(new GreaterThanElFunctionFactory());
		register(new GreaterThanAndEqualsElFunctionFactory());
		register(new ValueElFunctionFactory());
		register(new MapElFunctionFactory());
		register(new SelectorElFunctionFactory());
	}

	public static void register(JsonAlgFunctionFactory<?> jsonAlgFunction) {
		Objects.requireNonNull(jsonAlgFunction);
		jsonAlgFunctionFactoryMap.put(jsonAlgFunction.getClass(), jsonAlgFunction);
	}

	public static JsonAlgFunction<?> matching(String exp) {
		JsonAlgFunction<?> findAggElFunction = null;
		for (Map.Entry<Class<?>, JsonAlgFunctionFactory<?>> item : jsonAlgFunctionFactoryMap.entrySet()) {
			if (null != (findAggElFunction = item.getValue().matchingAndNew(exp))) {
				return findAggElFunction;
			}
		}
		throw new RuntimeException(String.format("this is illegal el[%s]", exp));
	}
}
