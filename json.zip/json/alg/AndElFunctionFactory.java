package com.wu.rcs.rules.utils.json.alg;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.google.gson.JsonElement;

/**
 * @author:MG01867
 * @date:2018年4月20日
 * @E-mail:359852326@qq.com
 * @version:
 * @describe and(子表达式1,子表达式2,子表达式n) json and算法，当所有子表达式成立时返回true
 */
public class AndElFunctionFactory extends AbstractJsonExpFunctionFactory<Boolean> {

	@SuppressWarnings("unchecked")
	@Override
	protected JsonAlgFunction<Boolean> doMatchingAndNew(String expression) {
		if (StringUtils.startsWith(expression, "and(")) {
			String parameterStr = StringUtils.substringAfter(expression, "and(");
			parameterStr = StringUtils.substringBeforeLast(parameterStr, ")");
			List<String> subrExps = parserParameter(parameterStr);
			if (subrExps.size() > 0) {
				List<JsonAlgFunction<Boolean>> subrAggElFunctions = new ArrayList<>(subrExps.size());
				for (int j = 0; j < subrExps.size(); j++) {
					JsonAlgFunction<Boolean> subrAggElFunction = (JsonAlgFunction<Boolean>) JsonExpFunctionFactoryRegister
							.matching(subrExps.get(j));
					subrAggElFunctions.add(subrAggElFunction);
				}
				return new AndElFunction(subrAggElFunctions);
			} else {
				throw new RuntimeException(String.format("this is illegal jsonExp[%s]", expression));
			}
		}
		return null;
	}

	class AndElFunction implements JsonAlgFunction<Boolean> {

		private List<JsonAlgFunction<Boolean>> subrAggElFunctions;

		private AndElFunction(List<JsonAlgFunction<Boolean>> subrAggElFunctions) {
			this.subrAggElFunctions = subrAggElFunctions;
		}

		@Override
		public Boolean getResult(JsonElement element) {
			for (JsonAlgFunction<Boolean> subrAggElFunction : subrAggElFunctions) {
				Boolean subrResult = subrAggElFunction.getResult(element);
				if (Boolean.FALSE == subrResult) {
					return Boolean.FALSE;
				}
			}
			return Boolean.TRUE;
		}
	}
}
