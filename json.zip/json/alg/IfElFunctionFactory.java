package com.wu.rcs.rules.utils.json.alg;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.google.gson.JsonElement;

/**
 * @author:MG01867
 * @date:2018年4月21日
 * @E-mail:359852326@qq.com
 * @version:
 * @describe if(true,result1,result2) json
 *           if条件判断算法，当子表达式结果为true时返回result1,否则返回result2
 */
public class IfElFunctionFactory extends AbstractJsonExpFunctionFactory<Object> {

	@SuppressWarnings("unchecked")
	@Override
	protected JsonAlgFunction<Object> doMatchingAndNew(String expression) {
		if (StringUtils.startsWith(expression, "if(")) {
			String parameterStr = StringUtils.substringAfter(expression, "if(");
			parameterStr = StringUtils.substringBeforeLast(parameterStr, ")");
			List<String> subrExps = parserParameter(parameterStr);
			if (subrExps.size() == 3) {
				JsonAlgFunction<Boolean> subrAggElFunction = (JsonAlgFunction<Boolean>) JsonExpFunctionFactoryRegister
						.matching(subrExps.get(0));
				return new IfElFunction(subrAggElFunction, subrExps.get(1), subrExps.get(2));
			} else {
				throw new RuntimeException(String.format("this is illegal jsonExp[%s]", expression));
			}
		}
		return null;
	}

	class IfElFunction implements JsonAlgFunction<Object> {

		private JsonAlgFunction<Boolean> subrAggElFunction;
		private Object trueResultValue;
		private Object falseResultValue;

		private IfElFunction(JsonAlgFunction<Boolean> subrAggElFunction, Object trueResultValue,
				Object falseResultValue) {
			this.subrAggElFunction = subrAggElFunction;
			this.trueResultValue = trueResultValue;
			this.falseResultValue = falseResultValue;
		}

		@Override
		public Object getResult(JsonElement element) {
			Boolean result = subrAggElFunction.getResult(element);
			if (Boolean.TRUE == result) {
				return trueResultValue;
			} else {
				return falseResultValue;
			}
		}
	}

}
