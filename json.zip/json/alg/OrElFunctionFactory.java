package com.wu.rcs.rules.utils.json.alg;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.google.gson.JsonElement;

/**
 * @author:MG01867
 * @date:2018年4月20日
 * @E-mail:359852326@qq.com
 * @version:
 * @describe or(子表达式1,子表达式2,子表达式n) 只要其中一个子表达式为true那么返回true,否则false
 */
public class OrElFunctionFactory extends AbstractJsonExpFunctionFactory<Boolean> {

	@SuppressWarnings("unchecked")
	@Override
	protected JsonAlgFunction<Boolean> doMatchingAndNew(String expression) {
		if (StringUtils.startsWith(expression, "or(")) {
			String parameterStr = StringUtils.substringAfter(expression, "or(");
			parameterStr = StringUtils.substringBeforeLast(parameterStr, ")");
			List<String> subrExps = parserParameter(parameterStr);
			if (subrExps.size() > 0) {
				List<JsonAlgFunction<Boolean>> subrAggElFunctions = new ArrayList<>(subrExps.size());
				for (int j = 0; j < subrExps.size(); j++) {
					JsonAlgFunction<Boolean> subrAggElFunction = (JsonAlgFunction<Boolean>) JsonExpFunctionFactoryRegister
							.matching(subrExps.get(j));
					subrAggElFunctions.add(subrAggElFunction);
				}
				return new OrElFunction(subrAggElFunctions);
			} else {
				throw new RuntimeException(String.format("this is illegal jsonExp[%s]", expression));
			}
		}
		return null;
	}

	class OrElFunction implements JsonAlgFunction<Boolean> {

		private List<JsonAlgFunction<Boolean>> subrAggElFunctions;

		private OrElFunction(List<JsonAlgFunction<Boolean>> subrAggElFunctions) {
			this.subrAggElFunctions = subrAggElFunctions;
		}

		@Override
		public Boolean getResult(JsonElement element) {
			for (JsonAlgFunction<Boolean> subrAggElFunction : subrAggElFunctions) {
				Boolean subrResult = subrAggElFunction.getResult(element);
				if (Boolean.TRUE == subrResult) {
					return Boolean.TRUE;
				}
			}
			return Boolean.FALSE;
		}
	}
}
