package com.wu.rcs.rules.utils.json.alg;

/**
 * @author:MG01867
 * @date:2018年4月21日
 * @E-mail:359852326@qq.com
 * @version:
 * @describe //TODO
 */
public abstract class AbstractJsonExpFunction<T> implements JsonAlgFunction<T>, JsonAlgFunctionFactory<T> {

	public final JsonAlgFunction<T> matchingAndNew(String expression) {
		if (null != expression && expression.length() > 0) {
			expression = expression.trim();
			return doMatchingAndNew(expression);
		}
		throw new RuntimeException(String.format("this is illegal jsonExp[%s]", expression));
	}

	protected abstract JsonAlgFunction<T> doMatchingAndNew(String expression);

}
