package com.wu.rcs.rules.utils.json.alg;

/**
 * @author:MG01867
 * @date:2018年4月20日
 * @E-mail:359852326@qq.com
 * @version:
 * @describe json算法接口工厂
 */
public interface JsonAlgFunctionFactory<T> {

	JsonAlgFunction<T> matchingAndNew(String expression);
}
