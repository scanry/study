package com.wu.rcs.rules.utils.json.alg;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;

import com.google.gson.JsonElement;
import com.wu.rcs.rules.utils.el.ELFactory;
import com.wu.rcs.rules.utils.el.function.Default;
import com.wu.rcs.rules.utils.el.function.Function;
import com.wu.rcs.rules.utils.el.function.OptFunction;

/**
 * @author:MG01867
 * @date:2018年4月20日
 * @E-mail:359852326@qq.com
 * @version:
 * @describe selector(jsonKey1,jsonKey2,jsonKey3) 只要其中一个jsonKey获取到json元素则返回此元素
 */
public class SelectorElFunctionFactory extends AbstractJsonExpFunctionFactory<JsonElement> {

	static Set<Character> specialCharSet = new HashSet<>();
	static {
		specialCharSet.add('|');
		specialCharSet.add('&');
		// specialCharSet.add('(');
		// specialCharSet.add(')');
		specialCharSet.add(',');
		specialCharSet.add(' ');
	}

	@Override
	protected JsonAlgFunction<JsonElement> doMatchingAndNew(String expression) {
		if (StringUtils.startsWith(expression, "selector(")) {
			String parameterStr = StringUtils.substringAfter(expression, "selector(");
			parameterStr = StringUtils.substringBeforeLast(parameterStr, ")");
			List<String> jsonKeys = parserParameter(parameterStr);
			if (jsonKeys.size() > 0) {
				for (int j = 0; j < jsonKeys.size(); j++) {
					checkJsonKey(jsonKeys.get(j));
				}
				return new SelectorElFunction(jsonKeys);
			} else {
				throw new RuntimeException(String.format("this is illegal jsonExp[%s]", expression));
			}
		}
		return null;
	}

	private static void checkJsonKey(String jsonKey) {
		if (null == jsonKey || jsonKey.length() == 0) {
			throw new RuntimeException(String.format("this is illegal jsonKey[%s]", jsonKey));
		}
		for (char c : jsonKey.toCharArray()) {
			if (specialCharSet.contains(c)) {
				throw new RuntimeException(String.format("this is illegal jsonKey[%s]", jsonKey));
			}
		}
	}

	class SelectorElFunction implements JsonAlgFunction<JsonElement> {

		private List<String> jsonKeys;

		private SelectorElFunction(List<String> jsonKeys) {
			this.jsonKeys = jsonKeys;
		}

		@Override
		public JsonElement getResult(JsonElement element) {
			JsonElement findJsonElement = null;
			for (String jsonKey : jsonKeys) {
				try {
					findJsonElement = findJsonElement(jsonKey, element);
					if (null != findJsonElement) {
						break;
					}
				} catch (Exception e) {
					// 这里异常忽略，异常时返回未找到null给业务处理即可
				}
			}
			return findJsonElement;
		}

		private JsonElement findJsonElement(String expression, JsonElement element) {
			String[] exps = expression.split("[.]");
			JsonElement defaultElement = null;
			JsonElement findElement = element;
			for (String exp : exps) {
				Function fun = ELFactory.executeFunction(exp);
				if (fun instanceof Default) {
					defaultElement = ((Default) fun).handler(exp, element);
				} else if (fun instanceof OptFunction) {
					findElement = ((OptFunction) fun).handler(exp, findElement);
				}
			}
			if (null == findElement && null != defaultElement) {
				findElement = defaultElement;
			}
			return findElement;
		}
	}

}
