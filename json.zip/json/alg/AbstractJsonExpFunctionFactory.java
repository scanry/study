package com.wu.rcs.rules.utils.json.alg;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

/**
 * @author:MG01867
 * @date:2018年4月21日
 * @E-mail:359852326@qq.com
 * @version:
 * @describe json算法工厂抽象类
 */
public abstract class AbstractJsonExpFunctionFactory<T> implements JsonAlgFunctionFactory<T> {

	/** 参数分隔符号 **/
	private static char PARAMETER_SPLIT_CHAR = ',';

	/** 左圆括号 **/
	private static char LEFT_PARENTHESES = '(';
	/** 右圆括号 **/
	private static char RIGHT_PARENTHESES = ')';

	/** 左花括号 **/
	private static char LEFT_CBRACES = '{';
	/** 右花括号 **/
	private static char RIGHT_CBRACES = '}';

	/** 左大括号 **/
	private static char LEFT_BRACES = '[';
	/** 右大括号 **/
	private static char RIGHT_BRACES = ']';

	@Override
	public final JsonAlgFunction<T> matchingAndNew(String expression) {
		if (null != expression && expression.length() > 0 && StringUtils.endsWith(expression, ")")) {
			expression = expression.trim();
			try {
				return doMatchingAndNew(expression);
			} catch (Exception exception) {
				throw new RuntimeException(String.format("this is illegal expression:%s", expression), exception);
			}
		}
		throw new RuntimeException(String.format("this is illegal expression:%s", expression));
	}

	protected abstract JsonAlgFunction<T> doMatchingAndNew(String expression);

	/**
	 * 根据给定的括号内表达式获取其参数
	 * 
	 * @param expression
	 *            比如parserParameter(expression1)函数，那么expression就是expression1
	 * @return 返回参数列表集合
	 */
	public static List<String> parserParameter(String expression) {
		List<String> parameters = new ArrayList<>();
		if (null != expression && expression.length() > 0) {
			int parenthesesDepth = 0;
			int cbracesDepth = 0;
			int bracesDepth = 0;
			int lastIndex = 0;
			for (int i = 0, size = expression.length(); i < size; i++) {
				char iteration = expression.charAt(i);
				if (LEFT_PARENTHESES == iteration) {
					parenthesesDepth++;
				}

				if (LEFT_CBRACES == iteration) {
					cbracesDepth++;
				}

				if (LEFT_BRACES == iteration) {
					bracesDepth++;
				}

				if (RIGHT_PARENTHESES == iteration) {
					parenthesesDepth--;
				}

				if (RIGHT_CBRACES == iteration) {
					cbracesDepth--;
				}

				if (RIGHT_BRACES == iteration) {
					bracesDepth--;
				}
				if (PARAMETER_SPLIT_CHAR == iteration && 0 == parenthesesDepth && 0 == cbracesDepth
						&& 0 == bracesDepth) {
					String parameter = expression.substring(lastIndex, i);
					lastIndex = i + 1;
					if (null != parameter && parameter.length() > 0) {
						parameters.add(parameter);
					}
				}
				if (i == size - 1) {
					String parameter = expression.substring(lastIndex, size);
					if (null != parameter && parameter.length() > 0) {
						parameters.add(parameter);
					}
				}
			}
		}
		return parameters;
	}

}
