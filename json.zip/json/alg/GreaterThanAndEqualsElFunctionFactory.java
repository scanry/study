package com.wu.rcs.rules.utils.json.alg;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;

import com.google.gson.JsonElement;

/**
*@author:MG01867
*@date:2018年4月21日
*@E-mail:359852326@qq.com
*@version:
*@describe gteq(子表达式1,比较值) json 大于等于比较算法，当子表达式结果大于等于期望值时返回true，否则false
*/
public class GreaterThanAndEqualsElFunctionFactory extends AbstractJsonExpFunctionFactory<Boolean> {

	@SuppressWarnings("unchecked")
	@Override
	protected JsonAlgFunction<Boolean> doMatchingAndNew(String expression) {
		if (StringUtils.startsWith(expression, "gteq(")) {
			String parameterStr = StringUtils.substringAfter(expression, "gteq(");
			parameterStr = StringUtils.substringBeforeLast(parameterStr, ")");
			List<String> subrExps = parserParameter(parameterStr);
			if (subrExps.size() == 2) {
				String equalsValueStr=subrExps.get(1);
				Number mix=null;
				if(NumberUtils.isParsable(equalsValueStr)) {
					mix=NumberUtils.createNumber(subrExps.get(1));
					JsonAlgFunction<Object> subrAggElFunction = (JsonAlgFunction<Object>) JsonExpFunctionFactoryRegister
							.matching(subrExps.get(0));
					return new GreaterThanAndEqualsElFunction(subrAggElFunction,mix);
				}else {
					throw new RuntimeException(String.format("it's not a number:[%s]", equalsValueStr));
				}
			} else {
				throw new RuntimeException(String.format("this is illegal el[%s]", expression));
			}
		}
		return null;
	}

	class GreaterThanAndEqualsElFunction implements JsonAlgFunction<Boolean> {

		private JsonAlgFunction<Object> aggElFunction;
		private Number mix;

		private GreaterThanAndEqualsElFunction(JsonAlgFunction<Object> aggElFunction, Number mix) {
			this.aggElFunction = aggElFunction;
			this.mix = mix;
		}

		@Override
		public Boolean getResult(JsonElement element) {
			Object subrResult = aggElFunction.getResult(element);
			String subrResultStr=null;
			if (null!=subrResult&&NumberUtils.isParsable(subrResultStr=subrResult.toString())) {
				Number subrResultNum=NumberUtils.createNumber(subrResultStr);
				return subrResultNum.doubleValue() > mix.doubleValue() ? Boolean.TRUE : Boolean.FALSE;
			} else {
				return Boolean.FALSE;
			}
		}
	}
}
