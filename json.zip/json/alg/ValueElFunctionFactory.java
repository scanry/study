package com.wu.rcs.rules.utils.json.alg;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.google.gson.JsonElement;

/**
 * @author:MG01867
 * @date:2018年4月20日
 * @E-mail:359852326@qq.com
 * @version:
 * @describe value(selector函数) 或者 value(selector函数,默认值)
 *           通过selector函数获取json运算，返回该元素值，如果jsonKey的结果为null,并且提供了默认值那么返回默认值
 */
public class ValueElFunctionFactory extends AbstractJsonExpFunctionFactory<Object> {

	@SuppressWarnings("unchecked")
	@Override
	protected JsonAlgFunction<Object> doMatchingAndNew(String expression) {
		if (StringUtils.startsWith(expression, "value(")) {
			String parameterStr = StringUtils.substringAfter(expression, "value(");
			parameterStr = StringUtils.substringBeforeLast(parameterStr, ")");
			List<String> subrExps = parserParameter(parameterStr);
			if (subrExps.size() == 1) {
				JsonAlgFunction<JsonElement> subrAggElFunction = (JsonAlgFunction<JsonElement>) JsonExpFunctionFactoryRegister
						.matching(subrExps.get(0));
				return new ValueElFunction(subrAggElFunction, null);
			} else if (subrExps.size() == 2) {
				JsonAlgFunction<JsonElement> subrAggElFunction = (JsonAlgFunction<JsonElement>) JsonExpFunctionFactoryRegister
						.matching(subrExps.get(1));
				return new ValueElFunction(subrAggElFunction, subrExps.get(0));
			} else {
				throw new RuntimeException(String.format("this is illegal jsonExp[%s]", expression));
			}
		}
		return null;
	}

	class ValueElFunction implements JsonAlgFunction<Object> {

		private JsonAlgFunction<JsonElement> subrAggElFunction;
		private Object defaultValue;

		private ValueElFunction(JsonAlgFunction<JsonElement> subrAggElFunction, Object defaultValue) {
			this.subrAggElFunction = subrAggElFunction;
			this.defaultValue = defaultValue;
		}

		@Override
		public Object getResult(JsonElement element) {
			JsonElement result = subrAggElFunction.getResult(element);
			if (null != result) {
				return result.getAsString();
			}
			if (null != defaultValue) {
				return defaultValue;
			}
			return null;
		}
	}
}