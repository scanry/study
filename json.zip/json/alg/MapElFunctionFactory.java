package com.wu.rcs.rules.utils.json.alg;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.google.gson.JsonElement;
import com.wu.rcs.rules.utils.GsonUtils;

/**
*@author:MG01867
*@date:2018年4月21日
*@E-mail:359852326@qq.com
*@version:
*@describe map(子表达式,映射map json) 通过子表达式的结果获取映射map中对应的值
*/
public class MapElFunctionFactory extends AbstractJsonExpFunctionFactory<Object> {

	@SuppressWarnings("unchecked")
	@Override
	protected JsonAlgFunction<Object> doMatchingAndNew(String expression) {
		if (StringUtils.startsWith(expression, "map(")) {
			String parameterStr = StringUtils.substringAfter(expression, "map(");
			parameterStr = StringUtils.substringBeforeLast(parameterStr, ")");
			List<String> subrExps = parserParameter(parameterStr);
			if (subrExps.size()==2) {
				JsonAlgFunction<Object> subrAggElFunction =(JsonAlgFunction<Object>)JsonExpFunctionFactoryRegister.matching(subrExps.get(0));
				Map<String,Object> mapping=GsonUtils.fromMap(subrExps.get(1));
				return new MapElFunction(subrAggElFunction,mapping);
			} else {
				throw new RuntimeException(String.format("this is illegal mapElFunction expression:%s", expression));
			}
		}
		return null;
	}

	class MapElFunction implements JsonAlgFunction<Object> {

		private JsonAlgFunction<Object> valueElFunction;
		private Map<String,Object> mapping;

		private MapElFunction(JsonAlgFunction<Object> valueElFunction,Map<String,Object> mapping) {
			this.valueElFunction = valueElFunction;
			this.mapping = mapping;
		}

		@Override
		public Object getResult(JsonElement element) {
			Object subrValue=valueElFunction.getResult(element);
			return mapping.get(subrValue);
		}
	}

}
