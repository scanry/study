package com.wu.rcs.rules.rule.handlers;

import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wu.rcs.rules.utils.GsonUtils;

/**
 * @author:MG01867
 * @date:2018年4月19日
 * @E-mail:359852326@qq.com
 * @version:
 * @describe //TODO
 */
public class BairongHandler extends AnstractIHandler {

	static final Logger logger = LoggerFactory.getLogger(BairongHandler.class);

	@Override
	protected Map<String, String> getRules() {
		Map<String, String> rules = new LinkedHashMap<>();

		/** 手机号三要素验证结果 **/
		Map<Object, Object> telecomThreeMap = new LinkedHashMap<>();
		// 移动手机号三要素验证映射
		telecomThreeMap.put("1", "1");
		telecomThreeMap.put("0", "0");
		telecomThreeMap.put("2", "0");
		telecomThreeMap.put("4", "0");
		// 联通手机号三要素验证映射
		telecomThreeMap.put("1", "1");
		telecomThreeMap.put("0", "0");
		telecomThreeMap.put("2", "0");
		telecomThreeMap.put("4", "0");
		telecomThreeMap.put("5", "0");
		// 电信手机号三要素验证映射
		telecomThreeMap.put("1", "1");
		telecomThreeMap.put("0", "0");
		telecomThreeMap.put("2", "0");
		telecomThreeMap.put("4", "0");
		rules.put("Main.BRSJ.StatisTel.VBRTG2",
				"map(value(selector(product.result))," + GsonUtils.toJson(telecomThreeMap) + ")");

		/** 手机号在网时长 **/
		Map<Object, Object> telecomDurationMap = new LinkedHashMap<>();
		// 无结果
		telecomDurationMap.put("0", "0");
		// 移动手机号在网时长[0-3）：三个月以下； [3-6）：三到六个月； [6-12）：六到十二个月； [12-18）：十二到十八个月；
		// [18-24）：十八到二十四个月； >24 ：二十四个月以上
		telecomDurationMap.put("0-3", "1");
		telecomDurationMap.put("3-6", "2");
		telecomDurationMap.put("6-12", "3");
		telecomDurationMap.put("12-18", "4");
		telecomDurationMap.put("18-24", "4");
		telecomDurationMap.put(">24", "5");
		// 联通手机号在网时长0.无结果 1.[0,3] 2.(3,6] 3.(6,12] 4.(12,24] 5.(24,36] 6.(36,+) 单位：月
		telecomDurationMap.put("1个月及以下（用户状态正常时，含义为当月入网）", "1");
		telecomDurationMap.put("2个月（用户状态正常时，含义为上个月入网）", "1");
		telecomDurationMap.put("3-6个月", "2");
		telecomDurationMap.put("7-12个月", "3");
		telecomDurationMap.put("13-24个月", "4");
		telecomDurationMap.put("25-36个月", "5");
		telecomDurationMap.put("37个月及以上", "5");
		// 电信手机号在网时长A：[0-6)；B：[6-12)；C：[12-24)；D：[24-36)； E：[36,+) 单位：月
		telecomDurationMap.put("A", "1");
		telecomDurationMap.put("B", "3");
		telecomDurationMap.put("C", "4");
		telecomDurationMap.put("D", "5");
		telecomDurationMap.put("E", "5");
		rules.put("Main.BRSJ.StatisTel.VBRTG3",
				"map(value(0,selector(product.value,product.data.D1001,product.data[0].[1])),"
						+ GsonUtils.toJson(telecomDurationMap) + ")");

		/** 手机号在网状态 **/
		Map<Object, Object> phoneStatusMap = new LinkedHashMap<>();
		// 移动手机号在网状态 0 ：停机 1 ：在网 2 ：预销号 3 ：销号
		phoneStatusMap.put("1", "1");
		phoneStatusMap.put("0", "0");
		phoneStatusMap.put("2", "0");
		phoneStatusMap.put("3", "0");
		// 联通手机号在网状态 1:正常；2:异常；0:无结果
		phoneStatusMap.put("1", "1");
		phoneStatusMap.put("2", "0");
		phoneStatusMap.put("0", "0");
		// 电信手机号在网状态 1：正常； 2：停机；3：在网但不可用； 4：不在网；9：无法查询
		phoneStatusMap.put("1", "1");
		phoneStatusMap.put("2", "0");
		phoneStatusMap.put("3", "0");
		phoneStatusMap.put("4", "0");
		phoneStatusMap.put("9", "0");
		rules.put("Main.BRSJ.StatisTel.VBRTG4",
				"map(value(selector(product.status,product.data.D1002,product.data[0].[0])),"
						+ GsonUtils.toJson(phoneStatusMap) + ")");

		/** 存在法院执行记录（立案时间两年内、未履约、执行标的大于10000元） **/
		StringBuilder existCourtRecordElStrbd = new StringBuilder();
		existCourtRecordElStrbd.append("if(or(");
		existCourtRecordElStrbd.append(
				"and(lteq(value(selector(ex_bad1_time)),2),eq(value(selector(ex_bad1_unperformpart)),1),gt(value(selector(ex_execut1_money)),10000)),");
		existCourtRecordElStrbd.append(
				"and(lteq(value(selector(ex_bad2_time)),3),eq(value(selector(ex_bad2_unperformpart)),1),gt(value(selector(ex_execut2_money)),10000)),");
		existCourtRecordElStrbd.append(
				"and(lteq(value(selector(ex_bad3_time)),3),eq(value(selector(ex_bad3_unperformpart)),1),gt(value(selector(ex_execut3_money)),10000)),");
		existCourtRecordElStrbd.append(
				"and(lteq(value(selector(ex_bad4_time)),3),eq(value(selector(ex_bad4_unperformpart)),1),gt(value(selector(ex_execut4_money)),10000)),");
		existCourtRecordElStrbd.append(
				"and(lteq(value(selector(ex_bad5_time)),3),eq(value(selector(ex_bad5_unperformpart)),1),gt(value(selector(ex_execut5_money)),10000)),");
		existCourtRecordElStrbd.append(
				"and(lteq(value(selector(ex_bad6_time)),3),eq(value(selector(ex_bad6_unperformpart)),1),gt(value(selector(ex_execut6_money)),10000)),");
		existCourtRecordElStrbd.append(
				"and(lteq(value(selector(ex_bad7_time)),3),eq(value(selector(ex_bad7_unperformpart)),1),gt(value(selector(ex_execut7_money)),10000)),");
		existCourtRecordElStrbd.append(
				"and(lteq(value(selector(ex_bad8_time)),3),eq(value(selector(ex_bad8_unperformpart)),1),gt(value(selector(ex_execut8_money)),10000)),");
		existCourtRecordElStrbd.append(
				"and(lteq(value(selector(ex_bad9_time)),3),eq(value(selector(ex_bad9_unperformpart)),1),gt(value(selector(ex_execut9_money)),10000)),");
		existCourtRecordElStrbd.append(
				"and(lteq(value(selector(ex_bad10_time)),3),eq(value(selector(ex_bad10_unperformpart)),1),gt(value(selector(ex_execut10_money)),10000))");
		existCourtRecordElStrbd.append("),1,0)");
		rules.put("Main.BRSJ.StatisExtend.VBRTH1", existCourtRecordElStrbd.toString());

		/** 按手机号查询，近3个月在非银机构申请次数 **/
		rules.put("Main.BRSJ.SpecialListApplyLoan.VBRB135", "value(selector(als_m3_cell_nbank_allnum))");

		/** 按身份证号查询，近3个月在非银机构申请次数 **/
		rules.put("Main.BRSJ.SpecialListApplyLoan.VBRB117", "value(selector(als_m3_id_nbank_allnum))");

		/** 借款人身份证号或手机号、百融标识是否触发高风险类特殊名单 **/
		StringBuilder highRiskElStrbd = new StringBuilder();
		highRiskElStrbd.append("if(or(");
		// 借款人身份证号百融标识是否触发高风险类特殊名单
		highRiskElStrbd.append("eq(value(selector(sl_id_bank_lost)),1),");
		highRiskElStrbd.append("eq(value(selector(sl_id_p2p_lost)),1),");
		highRiskElStrbd.append("eq(value(selector(sl_id_nbank_p2p_lost)),1),");
		highRiskElStrbd.append("eq(value(selector(sl_id_nbank_mc_lost)),1),");
		highRiskElStrbd.append("eq(value(selector(sl_id_nbank_ca_lost)),1),");
		highRiskElStrbd.append("eq(value(selector(sl_id_nbank_com_lost)),1),");
		highRiskElStrbd.append("eq(value(selector(sl_id_nbank_cf_lost)),1),");
		highRiskElStrbd.append("eq(value(selector(sl_id_nbank_other_lost)),1),");
		// 借款人手机号百融标识是否触发高风险类特殊名单
		highRiskElStrbd.append("eq(value(selector(sl_cell_bank_lost)),1),");
		highRiskElStrbd.append("eq(value(selector(sl_cell_p2p_lost)),1),");
		highRiskElStrbd.append("eq(value(selector(sl_cell_nbank_p2p_lost)),1),");
		highRiskElStrbd.append("eq(value(selector(sl_cell_nbank_mc_lost)),1),");
		highRiskElStrbd.append("eq(value(selector(sl_cell_nbank_ca_lost)),1),");
		highRiskElStrbd.append("eq(value(selector(sl_cell_nbank_com_lost)),1),");
		highRiskElStrbd.append("eq(value(selector(sl_cell_nbank_cf_lost)),1),");
		highRiskElStrbd.append("eq(value(selector(sl_cell_nbank_other_lost)),1),");
		highRiskElStrbd.append("),1,0)");
		rules.put("Main.BRSJ.StatisSpecialList.VBRTA1", highRiskElStrbd.toString());

		/** 借款人身份证号或手机号、百融标识是否触发中风险类特殊名单 **/
		StringBuilder midRiskElStrbd = new StringBuilder();
		midRiskElStrbd.append("if(or(");
		// 借款人身份证号百融标识是否触发中风险类特殊名单
		midRiskElStrbd.append("eq(value(selector(sl_id_bank_bad)),1),");
		midRiskElStrbd.append("eq(value(selector(sl_id_p2p_bad)),1),");
		midRiskElStrbd.append("eq(value(selector(sl_id_nbank_p2p_bad)),1),");
		midRiskElStrbd.append("eq(value(selector(sl_id_nbank_mc_bad)),1),");
		midRiskElStrbd.append("eq(value(selector(sl_id_nbank_ca_bad)),1),");
		midRiskElStrbd.append("eq(value(selector(sl_id_nbank_com_bad)),1),");
		midRiskElStrbd.append("eq(value(selector(sl_id_nbank_cf_bad)),1),");
		midRiskElStrbd.append("eq(value(selector(sl_id_nbank_other_bad)),1),");
		// 借款人手机号百融标识是否触发中风险类特殊名单
		midRiskElStrbd.append("eq(value(selector(sl_cell_bank_bad)),1),");
		midRiskElStrbd.append("eq(value(selector(sl_cell_p2p_bad)),1),");
		midRiskElStrbd.append("eq(value(selector(sl_cell_nbank_p2p_bad)),1),");
		midRiskElStrbd.append("eq(value(selector(sl_cell_nbank_mc_bad)),1),");
		midRiskElStrbd.append("eq(value(selector(sl_cell_nbank_ca_bad)),1),");
		midRiskElStrbd.append("eq(value(selector(sl_cell_nbank_com_bad)),1),");
		midRiskElStrbd.append("eq(value(selector(sl_cell_nbank_cf_bad)),1),");
		midRiskElStrbd.append("eq(value(selector(sl_cell_nbank_other_bad)),1),");
		midRiskElStrbd.append("),1,0)");
		rules.put("Main.BRSJ.StatisSpecialList.VBRTA2", midRiskElStrbd.toString());

		/** 借款人身份证号或手机号、百融标识是否触发低风险类特殊名单 **/
		StringBuilder lowRiskElStrbd = new StringBuilder();
		lowRiskElStrbd.append("if(or(");
		// 借款人身份证号百融标识是否触发低风险类特殊名单
		lowRiskElStrbd.append("eq(value(selector(sl_id_bank_overdue)),1),");
		lowRiskElStrbd.append("eq(value(selector(sl_id_p2p_overdue)),1),");
		lowRiskElStrbd.append("eq(value(selector(sl_id_nbank_p2p_overdue)),1),");
		lowRiskElStrbd.append("eq(value(selector(sl_id_nbank_mc_overdue)),1),");
		lowRiskElStrbd.append("eq(value(selector(sl_id_nbank_ca_overdue)),1),");
		lowRiskElStrbd.append("eq(value(selector(sl_id_nbank_com_overdue)),1),");
		lowRiskElStrbd.append("eq(value(selector(sl_id_nbank_cf_overdue)),1),");
		lowRiskElStrbd.append("eq(value(selector(sl_id_nbank_other_overdue)),1),");
		// 借款人手机号百融标识是否触发低风险类特殊名单
		lowRiskElStrbd.append("eq(value(selector(sl_cell_bank_overdue)),1),");
		lowRiskElStrbd.append("eq(value(selector(sl_cell_p2p_overdue)),1),");
		lowRiskElStrbd.append("eq(value(selector(sl_cell_nbank_p2p_overdue)),1),");
		lowRiskElStrbd.append("eq(value(selector(sl_cell_nbank_mc_overdue)),1),");
		lowRiskElStrbd.append("eq(value(selector(sl_cell_nbank_ca_overdue)),1),");
		lowRiskElStrbd.append("eq(value(selector(sl_cell_nbank_com_overdue)),1),");
		lowRiskElStrbd.append("eq(value(selector(sl_cell_nbank_cf_overdue)),1),");
		lowRiskElStrbd.append("eq(value(selector(sl_cell_nbank_other_overdue)),1),");
		lowRiskElStrbd.append("),1,0)");
		rules.put("Main.BRSJ.StatisSpecialList.VBRTA3", lowRiskElStrbd.toString());

		/** 借款人身份证号或手机号、百融标识是否触发高危行为类特殊名单 **/
		StringBuilder abnormalElStrbd = new StringBuilder();
		abnormalElStrbd.append("if(or(");
		// 借款人身份证号百融标识是否触发高危行为类特殊名单
		abnormalElStrbd.append("eq(value(selector(sl_id_abnormal)),1),");
		// 借款人手机号百融标识是否触发高危行为类特殊名单
		abnormalElStrbd.append("eq(value(selector(sl_cell_abnormal)),1),");
		abnormalElStrbd.append("),1,0)");
		rules.put("Main.BRSJ.StatisSpecialList.VBRTA6", abnormalElStrbd.toString());

		/** 借款人身份证号或手机号、百融标识是否触发电信欠费类特殊名单 **/
		StringBuilder overdueElStrbd = new StringBuilder();
		overdueElStrbd.append("if(or(");
		overdueElStrbd.append("eq(value(selector(sl_id_phone_overdue)),1),");//
		// 借款人身份证号百融标识是否触发电信欠费类特殊名单
		overdueElStrbd.append("eq(value(selector(sl_cell_phone_overdue)),1)");//
		// 借款人手机号百融标识是否触发电信欠费类特殊名单
		overdueElStrbd.append("),1,0)");
		rules.put("Main.BRSJ.StatisSpecialList.VBRTA7", overdueElStrbd.toString());

		/** 借款人身份证号或手机号、百融标识是否触发法院失信人类特殊名单 **/
		rules.put("Main.BRSJ.StatisSpecialList.VBRTA8", "if(eq(value(selector(sl_id_court_bad)),1),1,0)");

		/** 借款人身份证号或手机号、百融标识是否触发资信不佳类特殊名单 **/
		StringBuilder fraudElStrbd = new StringBuilder();
		fraudElStrbd.append("if(or(");
		// 借款人身份证百融标识是否触发资信不佳类特殊名单
		fraudElStrbd.append("eq(value(selector(sl_id_bank_fraud)),1),");
		fraudElStrbd.append("eq(value(selector(sl_id_p2p_fraud)),1),");
		fraudElStrbd.append("eq(value(selector(sl_id_nbank_p2p_fraud)),1),");
		fraudElStrbd.append("eq(value(selector(sl_id_nbank_mc_fraud)),1),");
		fraudElStrbd.append("eq(value(selector(sl_id_nbank_ca_fraud)),1),");
		fraudElStrbd.append("eq(value(selector(sl_id_nbank_com_fraud)),1),");
		fraudElStrbd.append("eq(value(selector(sl_id_nbank_cf_fraud)),1),");
		fraudElStrbd.append("eq(value(selector(sl_id_nbank_other_fraud)),1),");
		// 借款人手机号百融标识是否触发资信不佳类特殊名单
		fraudElStrbd.append("eq(value(selector(sl_cell_bank_fraud)),1),");
		fraudElStrbd.append("eq(value(selector(sl_cell_p2p_fraud)),1),");
		fraudElStrbd.append("eq(value(selector(sl_cell_nbank_p2p_fraud)),1),");
		fraudElStrbd.append("eq(value(selector(sl_cell_nbank_mc_fraud)),1),");
		fraudElStrbd.append("eq(value(selector(sl_cell_nbank_ca_fraud)),1),");
		fraudElStrbd.append("eq(value(selector(sl_cell_nbank_com_fraud)),1),");
		fraudElStrbd.append("eq(value(selector(sl_cell_nbank_cf_fraud)),1),");
		fraudElStrbd.append("eq(value(selector(sl_cell_nbank_other_fraud)),1)");
		fraudElStrbd.append("),1,0)");
		rules.put("Main.BRSJ.StatisSpecialList.VBRTA9", fraudElStrbd.toString());

		/** 借款人身份证号或手机号、百融标识是否触发拒绝类特殊名单 **/
		StringBuilder refuseElStrbd = new StringBuilder();
		refuseElStrbd.append("if(or(");
		// 借款人身份证号百融标识是否触发拒绝类特殊名单
		refuseElStrbd.append("eq(value(selector(sl_id_bank_refuse)),1),");
		refuseElStrbd.append("eq(value(selector(sl_id_p2p_refuse)),1),");
		refuseElStrbd.append("eq(value(selector(sl_id_nbank_p2p_refuse)),1),");
		refuseElStrbd.append("eq(value(selector(sl_id_nbank_mc_refuse)),1),");
		refuseElStrbd.append("eq(value(selector(sl_id_nbank_ca_refuse)),1),");
		refuseElStrbd.append("eq(value(selector(sl_id_nbank_com_refuse)),1),");
		refuseElStrbd.append("eq(value(selector(sl_id_nbank_cf_refuse)),1),");
		refuseElStrbd.append("eq(value(selector(sl_id_nbank_other_refuse)),1),");
		// 借款人手机号百融标识是否触发拒绝类特殊名单
		refuseElStrbd.append("eq(value(selector(sl_cell_bank_refuse)),1),");
		refuseElStrbd.append("eq(value(selector(sl_cell_p2p_refuse)),1),");
		refuseElStrbd.append("eq(value(selector(sl_cell_nbank_p2p_refuse)),1),");
		refuseElStrbd.append("eq(value(selector(sl_cell_nbank_mc_refuse)),1),");
		refuseElStrbd.append("eq(value(selector(sl_cell_nbank_ca_refuse)),1),");
		refuseElStrbd.append("eq(value(selector(sl_cell_nbank_com_refuse)),1),");
		refuseElStrbd.append("eq(value(selector(sl_cell_nbank_cf_refuse)),1),");
		refuseElStrbd.append("eq(value(selector(sl_cell_nbank_other_refuse)),1)");
		refuseElStrbd.append("),1,0)");
		rules.put("Main.BRSJ.StatisSpecialList.VBRTA10", refuseElStrbd.toString());
		return rules;
	}
}
