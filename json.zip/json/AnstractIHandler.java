package com.wu.rcs.rules.rule.handlers;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.wu.rcs.rules.utils.json.alg.JsonAlgExecutor;
import com.wu.rcs.rules.utils.json.alg.JsonAlgFunction;
import com.wu.rcs.rules.utils.json.alg.JsonExpFunctionFactoryRegister;

/**
 * @author:MG01867
 * @date:2018年4月20日
 * @E-mail:359852326@qq.com
 * @version:
 * @describe //TODO
 */
public abstract class AnstractIHandler implements IHandler {

	@Override
	public Map<String, Object> handle(Map<String, Object> originResultMap) {
		Map<String, String> rules = getRules();
		Map<String, Object> result = new HashMap<String, Object>(rules.size());
		if (null == originResultMap || originResultMap.isEmpty()) {
			result = Collections.emptyMap();
		} else {
			result = new HashMap<String, Object>(rules.size());
			String resultJson = originResultMap.get("result").toString();
			JsonAlgExecutor eleJsonExcute = new JsonAlgExecutor(resultJson);
			JsonAlgFunction<?> aggElFunction=null;
			for (Map.Entry<String, String> item : rules.entrySet()) {
				aggElFunction=JsonExpFunctionFactoryRegister.matching(item.getValue());
				result.put(item.getKey(), eleJsonExcute.getValue(aggElFunction));
			}
		}
		return result;
	}

	protected abstract Map<String, String> getRules();

}
